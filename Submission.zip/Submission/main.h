#ifndef TOURMAN_H
#define TOURMAN_H


#define DEBUG 0
#define TIME 0

#include <iostream>
#include <string>
#include <fstream>

#endif // !TOURMAN_H